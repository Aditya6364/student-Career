import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import Hero from "@/components/sections/hero";
import JourneyTimeline from "@/components/sections/journey-timeline";
import ResourcesGrid from "@/components/sections/resources-grid";
import ProgramsOverview from "@/components/sections/programs-overview";
import Testimonials from "@/components/sections/testimonials";
import ContactSection from "@/components/sections/contact-section";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <JourneyTimeline />
        <ResourcesGrid />
        <ProgramsOverview />
        <Testimonials />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}

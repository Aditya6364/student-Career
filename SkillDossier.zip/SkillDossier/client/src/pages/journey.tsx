import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import JourneyTimeline from "@/components/sections/journey-timeline";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Journey() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Journey Hero */}
        <section className="py-20 bg-gradient-to-br from-primary/10 to-secondary/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6" data-testid="text-journey-hero-title">
              Your Professional Journey
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8" data-testid="text-journey-hero-description">
              Every successful career starts with a single step. Explore how Fynally guides you through each stage of your professional development.
            </p>
            <Link href="/contact">
              <Button size="lg" data-testid="button-start-journey" className="bg-primary text-primary-foreground hover:bg-primary/90">
                Start Your Journey Today
              </Button>
            </Link>
          </div>
        </section>

        <JourneyTimeline />

        {/* Journey CTA */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6" data-testid="text-journey-cta-title">
              Ready to Begin Your Journey?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8" data-testid="text-journey-cta-description">
              Join thousands of students and professionals who have transformed their careers with Fynally's comprehensive support system.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <Button size="lg" data-testid="button-get-started" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  Get Started
                </Button>
              </Link>
              <Link href="/resources">
                <Button variant="outline" size="lg" data-testid="button-explore-resources">
                  Explore Resources
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}

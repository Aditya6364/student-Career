import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import ProgramsOverview from "@/components/sections/programs-overview";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Programs() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Programs Hero */}
        <section className="py-20 bg-gradient-to-br from-accent/10 to-primary/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6" data-testid="text-programs-hero-title">
              Career Programs
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8" data-testid="text-programs-hero-description">
              Transform your career with our comprehensive programs designed to bridge the gap between learning and professional success.
            </p>
            <Link href="/contact">
              <Button size="lg" data-testid="button-apply-now" className="bg-accent text-accent-foreground hover:bg-accent/90">
                Apply Now
              </Button>
            </Link>
          </div>
        </section>

        <ProgramsOverview />

        {/* Programs CTA */}
        <section className="py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6" data-testid="text-programs-cta-title">
              Launch Your Career Today
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8" data-testid="text-programs-cta-description">
              Don't wait for opportunities to come to you. Take control of your career trajectory with our proven programs and expert guidance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <Button size="lg" data-testid="button-join-program" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  Join a Program
                </Button>
              </Link>
              <Link href="/journey">
                <Button variant="outline" size="lg" data-testid="button-learn-journey">
                  Learn About Our Journey
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}

import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import ContactSection from "@/components/sections/contact-section";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Contact() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Contact Hero */}
        <section className="py-20 bg-gradient-to-br from-primary/10 to-accent/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6" data-testid="text-contact-hero-title">
              Get In Touch
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8" data-testid="text-contact-hero-description">
              Ready to transform your career? We're here to help you take the next step towards professional success.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/journey">
                <Button variant="outline" size="lg" data-testid="button-learn-more">
                  Learn More About Our Journey
                </Button>
              </Link>
              <Link href="/programs">
                <Button variant="outline" size="lg" data-testid="button-view-programs">
                  View Our Programs
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <ContactSection />

        {/* Contact CTA */}
        <section className="py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6" data-testid="text-contact-cta-title">
              Still Have Questions?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8" data-testid="text-contact-cta-description">
              Our team is here to help you understand how Fynally can accelerate your career journey. Don't hesitate to reach out.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" data-testid="button-schedule-call" className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
                Schedule a Call
              </Button>
              <Link href="/resources">
                <Button variant="outline" size="lg" data-testid="button-browse-resources">
                  Browse Resources
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}

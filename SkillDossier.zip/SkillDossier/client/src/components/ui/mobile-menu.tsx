import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const [location] = useLocation();

  const navigation = [
    { name: "Home", href: "/" },
    { name: "Journey", href: "/journey" },
    { name: "Resources", href: "/resources" },
    { name: "Programs", href: "/programs" },
    { name: "Contact", href: "/contact" },
  ];

  // Close menu when route changes
  useEffect(() => {
    onClose();
  }, [location, onClose]);

  // Prevent body scroll when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 z-40 md:hidden"
        onClick={onClose}
        data-testid="mobile-menu-backdrop"
      />
      
      {/* Mobile Menu */}
      <div 
        className={cn(
          "fixed top-0 left-0 h-full w-80 max-w-[90vw] bg-background border-r border-border z-50 md:hidden transform transition-transform duration-300 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
        data-testid="mobile-menu"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="text-2xl font-bold text-primary">
            Fynally
            <span className="text-accent text-sm ml-1">.io</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            data-testid="button-close-mobile-menu"
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="h-6 w-6" />
          </Button>
        </div>

        {/* Navigation Links */}
        <nav className="p-4">
          <div className="space-y-2">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                data-testid={`mobile-nav-${item.name.toLowerCase()}`}
                className={cn(
                  "block px-4 py-3 rounded-lg text-base font-medium transition-colors",
                  location === item.href
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                )}
              >
                {item.name}
              </Link>
            ))}
          </div>

          {/* CTA Button */}
          <div className="mt-6 px-4">
            <Link href="/contact">
              <Button 
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                data-testid="mobile-cta-button"
              >
                Get Started
              </Button>
            </Link>
          </div>
        </nav>
      </div>
    </>
  );
}

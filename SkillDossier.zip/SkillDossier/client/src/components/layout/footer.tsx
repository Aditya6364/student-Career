import { Link } from "wouter";
import { Github, Linkedin, Twitter, Instagram, Youtube } from "lucide-react";

export default function Footer() {
  const quickLinks = [
    { name: "Home", href: "/" },
    { name: "Journey", href: "/journey" },
    { name: "Resources", href: "/resources" },
    { name: "Programs", href: "/programs" },
    { name: "Contact", href: "/contact" },
  ];

  const programs = [
    { name: "Internship Program", href: "/programs#internship" },
    { name: "Job Placement", href: "/programs#job-placement" },
    { name: "Skill Bootcamp", href: "/programs#bootcamp" },
    { name: "Mentorship", href: "/resources#mentorship" },
    { name: "Certifications", href: "/resources#certifications" },
  ];

  const support = [
    { name: "Help Center", href: "#" },
    { name: "Community", href: "#" },
    { name: "Privacy Policy", href: "#" },
    { name: "Terms of Service", href: "#" },
    { name: "Cookie Policy", href: "#" },
  ];

  const socialLinks = [
    { name: "LinkedIn", icon: Linkedin, href: "#" },
    { name: "Twitter", icon: Twitter, href: "#" },
    { name: "Instagram", icon: Instagram, href: "#" },
    { name: "YouTube", icon: Youtube, href: "#" },
  ];

  return (
    <footer className="bg-foreground text-background py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <div className="text-2xl font-bold text-background mb-4">
              Fynally
              <span className="text-accent text-sm ml-1">.io</span>
            </div>
            <p className="text-background/80 mb-6">
              Your life companion for career growth, guiding you from student to successful professional.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  data-testid={`social-${social.name.toLowerCase()}`}
                  className="w-10 h-10 bg-background/10 rounded-lg flex items-center justify-center text-background hover:bg-background/20 transition-colors"
                  aria-label={social.name}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-background mb-4">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    data-testid={`footer-link-${link.name.toLowerCase()}`}
                    className="text-background/80 hover:text-background transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Programs */}
          <div>
            <h4 className="text-lg font-semibold text-background mb-4">Programs</h4>
            <ul className="space-y-3">
              {programs.map((program) => (
                <li key={program.name}>
                  <a
                    href={program.href}
                    data-testid={`footer-program-${program.name.toLowerCase().replace(/\s+/g, '-')}`}
                    className="text-background/80 hover:text-background transition-colors"
                  >
                    {program.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-lg font-semibold text-background mb-4">Support</h4>
            <ul className="space-y-3">
              {support.map((item) => (
                <li key={item.name}>
                  <a
                    href={item.href}
                    data-testid={`footer-support-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                    className="text-background/80 hover:text-background transition-colors"
                  >
                    {item.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-background/20 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="text-background/80 text-sm mb-4 md:mb-0">
            © 2024 Fynally.io. All rights reserved.
          </div>
          <div className="flex items-center space-x-6 text-sm">
            <a href="#" data-testid="footer-privacy" className="text-background/80 hover:text-background transition-colors">
              Privacy
            </a>
            <a href="#" data-testid="footer-terms" className="text-background/80 hover:text-background transition-colors">
              Terms
            </a>
            <a href="#" data-testid="footer-cookies" className="text-background/80 hover:text-background transition-colors">
              Cookies
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { GraduationCap, Book, Briefcase, Trophy } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function JourneyTimeline() {
  const journeySteps = [
    {
      id: "student",
      title: "Student",
      icon: GraduationCap,
      color: "primary",
      description: "Build your academic foundation with our curated resources and study materials.",
      features: [
        "Academic Resources",
        "Study Materials",
        "Peer Connections",
        "Career Guidance",
      ],
    },
    {
      id: "learner",
      title: "Learner",
      icon: Book,
      color: "secondary",
      description: "Enhance your skills with industry-relevant courses and certifications.",
      features: [
        "Skill Development",
        "Online Courses",
        "Certifications",
        "Project Portfolio",
      ],
    },
    {
      id: "intern",
      title: "Intern",
      icon: Briefcase,
      color: "accent",
      description: "Gain real-world experience through our internship programs and partnerships.",
      features: [
        "Internship Matching",
        "Industry Experience",
        "Mentorship",
        "Professional Network",
      ],
    },
    {
      id: "employee",
      title: "Employee",
      icon: Trophy,
      color: "secondary",
      description: "Launch your career with job placements and continued professional growth.",
      features: [
        "Job Placements",
        "Career Growth",
        "Leadership Training",
        "Ongoing Support",
      ],
    },
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case "primary":
        return "bg-primary/10 text-primary";
      case "secondary":
        return "bg-secondary/10 text-secondary";
      case "accent":
        return "bg-accent/10 text-accent";
      default:
        return "bg-primary/10 text-primary";
    }
  };

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-journey-title">
            Your Career Journey with Fynally
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-journey-description">
            We support you at every stage of your professional development, from academic foundation to career success.
          </p>
        </div>

        {/* Journey Steps */}
        <div className="grid md:grid-cols-4 gap-8 relative">
          {/* Connection Line (Hidden on Mobile) */}
          <div className="hidden md:block absolute top-24 left-0 right-0 h-1 bg-gradient-to-r from-primary via-secondary to-accent opacity-30 z-0"></div>

          {journeySteps.map((step, index) => (
            <Card
              key={step.id}
              data-testid={`card-journey-${step.id}`}
              className="journey-step relative z-10 text-center shadow-lg border border-border hover:shadow-xl transition-all duration-300"
            >
              <CardContent className="p-8">
                <div className={`w-16 h-16 ${getColorClasses(step.color)} rounded-full flex items-center justify-center mx-auto mb-6`}>
                  <step.icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-4" data-testid={`text-${step.id}-title`}>
                  {step.title}
                </h3>
                <p className="text-muted-foreground mb-4" data-testid={`text-${step.id}-description`}>
                  {step.description}
                </p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  {step.features.map((feature, featureIndex) => (
                    <li key={featureIndex} data-testid={`text-${step.id}-feature-${featureIndex}`}>
                      • {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

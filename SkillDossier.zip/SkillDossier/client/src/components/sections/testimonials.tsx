import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function Testimonials() {
  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "Software Engineer at Google",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612c8c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      content: "Fynally transformed my career journey. From a confused student to landing my dream job at a top tech company. The mentorship and resources were invaluable.",
      rating: 5,
    },
    {
      id: 2,
      name: "Michael Chen",
      role: "Data Scientist at Microsoft",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      content: "The internship program connected me with amazing opportunities. I learned more in 6 months than I did in my entire degree. Now I'm a full-time data scientist!",
      rating: 5,
    },
    {
      id: 3,
      name: "Priya Patel",
      role: "Product Manager at Amazon",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      content: "From struggling with career direction to getting multiple job offers. Fynally's skill development programs and career coaching made all the difference.",
      rating: 5,
    },
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-testimonials-title">
            Success Stories
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-testimonials-description">
            Hear from students who transformed their careers with Fynally's guidance and support.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} data-testid={`card-testimonial-${testimonial.id}`} className="shadow-lg border border-border">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="flex text-accent" data-testid={`rating-${testimonial.id}`}>
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-muted-foreground mb-6 italic" data-testid={`text-testimonial-${testimonial.id}-content`}>
                  "{testimonial.content}"
                </p>
                <div className="flex items-center">
                  <img
                    src={testimonial.image}
                    alt={`Professional headshot of ${testimonial.name}`}
                    data-testid={`img-testimonial-${testimonial.id}`}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <div className="font-semibold text-foreground" data-testid={`text-testimonial-${testimonial.id}-name`}>
                      {testimonial.name}
                    </div>
                    <div className="text-sm text-muted-foreground" data-testid={`text-testimonial-${testimonial.id}-role`}>
                      {testimonial.role}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

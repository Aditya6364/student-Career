import { Bus, Rocket, Settings } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function ProgramsOverview() {
  const programs = [
    {
      id: "internship",
      title: "Internship Program",
      icon: Bus,
      color: "primary",
      description: "Get matched with top companies for internships that provide real-world experience and valuable industry connections.",
      features: [
        "3-6 month programs",
        "Mentorship included",
        "Performance feedback",
        "Potential job offers",
      ],
      cta: "Apply Now",
    },
    {
      id: "job-placement",
      title: "Job Placement Program",
      icon: Rocket,
      color: "secondary",
      description: "Fast-track your career with our job placement assistance and career coaching services.",
      features: [
        "Resume optimization",
        "Interview preparation",
        "Salary negotiation",
        "Job matching service",
      ],
      cta: "Get Started",
    },
    {
      id: "bootcamp",
      title: "Skill Development Bootcamp",
      icon: Settings,
      color: "accent",
      description: "Intensive training programs designed to equip you with in-demand skills for today's job market.",
      features: [
        "8-12 week intensive programs",
        "Hands-on projects",
        "Industry partnerships",
        "Job guarantee options",
      ],
      cta: "Learn More",
    },
  ];

  const getColorClasses = (color: string, type: "background" | "button") => {
    if (type === "background") {
      switch (color) {
        case "primary":
          return "bg-primary/10 text-primary";
        case "secondary":
          return "bg-secondary/10 text-secondary";
        case "accent":
          return "bg-accent/10 text-accent";
        default:
          return "bg-primary/10 text-primary";
      }
    } else {
      switch (color) {
        case "primary":
          return "bg-primary text-primary-foreground hover:bg-primary/90";
        case "secondary":
          return "bg-secondary text-secondary-foreground hover:bg-secondary/90";
        case "accent":
          return "bg-accent text-accent-foreground hover:bg-accent/90";
        default:
          return "bg-primary text-primary-foreground hover:bg-primary/90";
      }
    }
  };

  const stats = [
    { label: "Students Placed", value: "500+" },
    { label: "Success Rate", value: "95%" },
    { label: "Partner Companies", value: "50+" },
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-programs-title">
            Programs & Opportunities
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-programs-description">
            Discover internships, job opportunities, and specialized programs designed to launch your career.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Programs Content */}
          <div className="space-y-8">
            {programs.map((program) => (
              <Card key={program.id} data-testid={`card-program-${program.id}`} className="shadow-lg border border-border">
                <CardContent className="p-8">
                  <div className="flex items-start space-x-4">
                    <div className={`w-12 h-12 ${getColorClasses(program.color, "background")} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <program.icon className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-foreground mb-3" data-testid={`text-${program.id}-title`}>
                        {program.title}
                      </h3>
                      <p className="text-muted-foreground mb-4" data-testid={`text-${program.id}-description`}>
                        {program.description}
                      </p>
                      <ul className="text-sm text-muted-foreground space-y-1 mb-4">
                        {program.features.map((feature, index) => (
                          <li key={index} data-testid={`text-${program.id}-feature-${index}`}>
                            • {feature}
                          </li>
                        ))}
                      </ul>
                      <Button
                        data-testid={`button-${program.id}`}
                        className={getColorClasses(program.color, "button")}
                      >
                        {program.cta}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Programs Image and Stats */}
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              alt="Dynamic startup team working together in modern coworking space"
              data-testid="img-programs"
              className="rounded-2xl shadow-xl w-full h-auto"
            />

            {/* Stats Overlay */}
            <div className="absolute bottom-6 left-6 right-6 bg-background/95 backdrop-blur-sm p-6 rounded-xl border border-border" data-testid="stats-overlay">
              <div className="grid grid-cols-3 gap-4 text-center">
                {stats.map((stat, index) => (
                  <div key={index}>
                    <div className={`text-2xl font-bold ${index === 0 ? 'text-primary' : index === 1 ? 'text-secondary' : 'text-accent'}`} data-testid={`stat-value-${index}`}>
                      {stat.value}
                    </div>
                    <div className="text-sm text-muted-foreground" data-testid={`stat-label-${index}`}>
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

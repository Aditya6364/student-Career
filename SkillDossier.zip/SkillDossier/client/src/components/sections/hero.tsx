import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Hero() {
  return (
    <section className="hero-gradient text-primary-foreground py-20 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight" data-testid="text-hero-title">
              Your Life Companion for{" "}
              <span className="text-accent">Career Growth</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90 leading-relaxed" data-testid="text-hero-description">
              From student to employee, we guide your journey with resources, mentorship, and opportunities tailored for your success.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link href="/contact">
                <Button
                  size="lg"
                  data-testid="button-start-journey"
                  className="bg-accent text-accent-foreground px-8 py-4 text-lg font-semibold hover:bg-accent/90 shadow-lg"
                >
                  Start Your Journey
                </Button>
              </Link>
              <Link href="/journey">
                <Button
                  variant="outline"
                  size="lg"
                  data-testid="button-learn-more"
                  className="border-2 border-primary-foreground text-primary-foreground px-8 py-4 text-lg font-semibold hover:bg-primary-foreground hover:text-primary"
                >
                  Learn More
                </Button>
              </Link>
            </div>
          </div>

          {/* Hero Journey Visualization */}
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              alt="Diverse team collaborating in modern workspace"
              data-testid="img-hero"
              className="rounded-2xl shadow-2xl w-full h-auto transform hover:scale-105 transition-transform duration-300"
            />

            {/* Floating Journey Steps */}
            <div className="absolute -top-4 -left-4 bg-background text-foreground p-4 rounded-xl shadow-lg border border-border" data-testid="badge-student">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-primary rounded-full"></div>
                <span className="font-medium text-sm">Student</span>
              </div>
            </div>

            <div className="absolute top-1/2 -right-6 bg-background text-foreground p-4 rounded-xl shadow-lg border border-border" data-testid="badge-learner">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-secondary rounded-full"></div>
                <span className="font-medium text-sm">Learner</span>
              </div>
            </div>

            <div className="absolute -bottom-4 left-1/3 bg-background text-foreground p-4 rounded-xl shadow-lg border border-border" data-testid="badge-employee">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-accent rounded-full"></div>
                <span className="font-medium text-sm">Employee</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import { Video, FileText, Users, Award, Code, Handshake } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function ResourcesGrid() {
  const resources = [
    {
      id: "video-courses",
      title: "Video Courses",
      icon: Video,
      color: "primary",
      description: "High-quality video content covering technical skills, soft skills, and industry insights from experts.",
      cta: "Explore Courses",
    },
    {
      id: "study-materials",
      title: "Study Materials",
      icon: FileText,
      color: "secondary",
      description: "Comprehensive study guides, templates, and resources for academic and professional success.",
      cta: "Access Materials",
    },
    {
      id: "community-forums",
      title: "Community Forums",
      icon: Users,
      color: "accent",
      description: "Connect with peers, share experiences, and get support from our vibrant learning community.",
      cta: "Join Community",
    },
    {
      id: "certifications",
      title: "Certifications",
      icon: Award,
      color: "primary",
      description: "Industry-recognized certifications to validate your skills and boost your career prospects.",
      cta: "View Programs",
    },
    {
      id: "coding-practice",
      title: "Coding Practice",
      icon: Code,
      color: "secondary",
      description: "Interactive coding challenges and projects to sharpen your programming skills.",
      cta: "Start Coding",
    },
    {
      id: "mentorship",
      title: "Mentorship",
      icon: Handshake,
      color: "accent",
      description: "One-on-one guidance from industry professionals to accelerate your career growth.",
      cta: "Find Mentor",
    },
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case "primary":
        return "bg-primary/10 text-primary";
      case "secondary":
        return "bg-secondary/10 text-secondary";
      case "accent":
        return "bg-accent/10 text-accent";
      default:
        return "bg-primary/10 text-primary";
    }
  };

  return (
    <section className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-resources-title">
            Comprehensive Learning Resources
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-resources-description">
            Access curated content, tools, and materials designed to accelerate your learning and career development.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {resources.map((resource) => (
            <Card
              key={resource.id}
              data-testid={`card-resource-${resource.id}`}
              className="feature-hover shadow-lg border border-border transition-all duration-300 hover:shadow-xl"
            >
              <CardContent className="p-8">
                <div className={`w-12 h-12 ${getColorClasses(resource.color)} rounded-lg flex items-center justify-center mb-6`}>
                  <resource.icon className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-4" data-testid={`text-${resource.id}-title`}>
                  {resource.title}
                </h3>
                <p className="text-muted-foreground mb-6" data-testid={`text-${resource.id}-description`}>
                  {resource.description}
                </p>
                <Button
                  variant="link"
                  data-testid={`button-${resource.id}`}
                  className="text-primary font-medium hover:text-primary/80 transition-colors p-0"
                >
                  {resource.cta} →
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
